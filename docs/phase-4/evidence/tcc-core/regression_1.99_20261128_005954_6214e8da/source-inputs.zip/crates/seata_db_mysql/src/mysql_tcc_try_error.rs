use crate::DbError;
use seata_rm::{RegisteredBranch, RmCallError};
/// TCC Try 登记与本地事务失败；已确认原回执永不丢失或重造。
/// 对应 Java: TccActionInterceptorHandler 的登记/prepareFence 异常边界；Rust 原回执扩展。
#[derive(Debug, thiserror::Error)]
pub enum MySqlTccTryError {
    /// 原登记前的输入或配置拒绝。
    #[error("TCC Try rejected before registration")]
    Local {
        /// 脱敏本地原因。
        #[source]
        source: DbError,
    },
    /// 正式单次登记失败，保留请求可能生效语义。
    #[error(transparent)]
    Registration(#[from] RmCallError),
    /// 原登记已知，但 Fence/业务事务失败、拒绝或提交未确认。
    #[error("TCC registered transaction unresolved or refused")]
    Transaction {
        /// 原 TC 成功登记回执。
        receipt: Box<RegisteredBranch>,
        /// 脱敏本地原因。
        #[source]
        source: DbError,
    },
    /// 绝对期限，未知登记不能合成分支或否定原请求。
    #[error("TCC Try operation deadline exceeded")]
    Deadline {
        /// 已真实取得的原回执。
        receipt: Option<Box<RegisteredBranch>>,
        /// 单次登记是否可能已发送。
        registration_may_have_effect: bool,
    },
}
impl MySqlTccTryError {
    /// 无参数；返回真实原登记借用，None 不表示登记必定未生效。
    pub fn registered_branch(&self) -> Option<&RegisteredBranch> {
        match self {
            Self::Transaction { receipt, .. } => Some(receipt),
            Self::Deadline { receipt, .. } => receipt.as_deref(),
            _ => None,
        }
    }
}
