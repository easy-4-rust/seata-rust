use crate::{DbError,MySqlDataSource,MySqlTccTryError};
use seata_rm::{BranchIdentity,BranchPhase,BranchResolution,BranchResource,RegisteredBranch,ResourceClient,RmError};
use seata_protocol::{BranchType,transaction::BranchRegisterRequest};
use seata_transport::ResourceKey;
use seata_tcc::TccBusinessAction;
use std::{sync::Arc,fmt,future::Future,pin::Pin};
/// 同库持久 Fence 的 TCC 三阶段资源。
/// 对应 Java: org.apache.seata.rm.tcc.TCCResourceManager 与 org.apache.seata.rm.fence.SpringFenceHandler。
pub struct MySqlTccResourceManager { source:MySqlDataSource,key:ResourceKey,action:Arc<dyn TccBusinessAction> }
impl fmt::Debug for MySqlTccResourceManager{fn fmt(&self,f:&mut fmt::Formatter<'_>)->fmt::Result{f.debug_struct("MySqlTccResourceManager").field("key",&self.key).finish_non_exhaustive()}}
impl MySqlTccResourceManager {
    /// 参数为原数据源、原动作名及业务对象；返回独立 TCC 资源，不自动建表或登记。
    pub fn new(source:MySqlDataSource,action_name:String,action:Arc<dyn TccBusinessAction>)->Result<Self,DbError>{
        let key=ResourceKey::new(BranchType::Tcc,action_name).map_err(|_|DbError::Input{reason:"invalid TCC action name"})?;
        Ok(Self{source,key,action})
    }
    /// 参数为正式客户端、原 XID 和原应用数据；单次登记后执行本地 Try。
    pub async fn register_and_try(&self,client:&ResourceClient,xid:&str,application_data:Option<String>)->Result<RegisteredBranch,MySqlTccTryError>{
        let receipt=client.branch_register_with_receipt(BranchRegisterRequest{xid:Some(xid.into()),branch_type:BranchType::Tcc,resource_id:Some(self.key.resource_id().into()),lock_key:None,application_data}).await?;
        self.try_registered(receipt).await
    }
    /// 参数为原成功回执；不能从裸 XID/BranchId 构造 Try 权限。
    pub async fn try_registered(&self,receipt:RegisteredBranch)->Result<RegisteredBranch,MySqlTccTryError>{
        Err(MySqlTccTryError::Transaction{receipt:Box::new(receipt),source:DbError::Unsupported{feature:"TCC atomic execution not available"}})
    }
}
impl BranchResource for MySqlTccResourceManager {
    fn key(&self)->&ResourceKey{&self.key}
    fn apply<'a>(&'a self,_identity:&'a BranchIdentity,_phase:BranchPhase)->Pin<Box<dyn Future<Output=Result<BranchResolution,RmError>>+Send+'a>>{Box::pin(async{Ok(BranchResolution::Unknown)})}
    fn recover<'a>(&'a self,identity:&'a BranchIdentity,phase:BranchPhase)->Pin<Box<dyn Future<Output=Result<BranchResolution,RmError>>+Send+'a>>{self.apply(identity,phase)}
}
