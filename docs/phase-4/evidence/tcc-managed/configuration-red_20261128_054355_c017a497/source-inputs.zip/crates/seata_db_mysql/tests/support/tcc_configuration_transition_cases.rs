//! 报告清单已提交但 Try 未提交时，错误静态配置不得重放或污染原身份。
#![allow(clippy::unwrap_used)]
use super::{dynamic_action, fixture, manager, peer};
use seata_db_mysql::{MySqlDataSource, MySqlTccResourceManager};
use seata_protocol::ResultCode;
use seata_rm::{BranchIdentity, BranchPhase, BranchRecordState, BranchResource, RegisteredBranch};
use std::sync::Arc;
use tokio::net::TcpListener;

async fn manifest_only(
    name: &str,
) -> (
    sqlx::MySqlConnection,
    MySqlDataSource,
    Arc<MySqlTccResourceManager>,
    RegisteredBranch,
    BranchIdentity,
) {
    let (mut admin, source, _) = fixture::seed().await;
    sqlx::raw_sql("DROP TABLE IF EXISTS seata_rs_tcc_context_v1")
        .execute(&mut admin)
        .await
        .unwrap();
    sqlx::raw_sql(include_str!(
        "../../migrations/020_seata_rs_tcc_context_v1.sql"
    ))
    .execute(&mut admin)
    .await
    .unwrap();
    let dynamic = Arc::new(
        MySqlTccResourceManager::new(
            source.clone(),
            "tcc-original-action".into(),
            Arc::new(dynamic_action::TccDynamicAction {
                immediate: false,
                precision_only: false,
                catch_report_error: false,
                failure_mode: None,
            }),
        )
        .unwrap()
        .with_context_reporting(),
    );
    let listener = TcpListener::bind("127.0.0.1:0").await.unwrap();
    let (rm, store) = manager(dynamic.clone(), &listener, name).await;
    let xid = format!("tcc:configuration:{name}");
    let branch = 9901;
    let original = fixture::app(1);
    let expected = BranchIdentity::new(
        xid.clone(),
        branch,
        dynamic.key().clone(),
        Some(original.clone()),
    )
    .unwrap();
    let id = expected.clone();
    let server = tokio::spawn(async move {
        let mut socket = peer::bootstrap(&listener, id.resource().resource_id()).await;
        peer::registered(
            &mut socket,
            id.resource().resource_id(),
            id.xid(),
            id.application_data(),
            branch,
        )
        .await;
        let (_, app) = peer::read_context_report(&mut socket, &id).await;
        drop(socket);
        app
    });
    let error = dynamic
        .register_and_try(&rm.client(), &xid, Some(original))
        .await
        .unwrap_err();
    let receipt = error.registered_branch().unwrap().clone();
    let seata_db_mysql::MySqlTccTryError::ContextReport {
        source: reason,
        context_report_started,
        ..
    } = error
    else {
        panic!("report uncertainty type lost")
    };
    assert!(context_report_started);
    let seata_db_mysql::MySqlTccContextReportError::Rpc(reason) = *reason else {
        panic!("expected original report RPC uncertainty")
    };
    assert!(reason.is_unknown_outcome());
    let app = server.await.unwrap();
    assert!(fixture::business(&mut admin).await.is_empty());
    let count: i64 = sqlx::query_scalar("SELECT COUNT(*) FROM seata_rs_tcc_fence_v1")
        .fetch_one(&mut admin)
        .await
        .unwrap();
    assert_eq!(count, 0);
    let versions: i64 = sqlx::query_scalar("SELECT COUNT(*) FROM seata_rs_tcc_context_v1")
        .fetch_one(&mut admin)
        .await
        .unwrap();
    assert_eq!(versions, 2);
    assert_eq!(receipt.identity(), &expected);
    rm.shutdown().await.unwrap();
    drop(store);
    let current = BranchIdentity::new(xid, branch, dynamic.key().clone(), Some(app)).unwrap();
    (admin, source, dynamic, receipt, current)
}

#[tokio::test]
#[ignore = "requires owned MySQL and durable dynamic report origin"]
async fn static_try_cannot_replay_original_receipt_after_unconfirmed_dynamic_report() {
    let (mut admin, source, _, receipt, current) = manifest_only("static-try").await;
    let plain = MySqlTccResourceManager::new(
        source.clone(),
        "tcc-original-action".into(),
        Arc::new(fixture::Action::default()),
    )
    .unwrap();
    let result = plain.try_registered(receipt.clone()).await;
    let count: i64 = sqlx::query_scalar("SELECT COUNT(*) FROM seata_rs_tcc_fence_v1")
        .fetch_one(&mut admin)
        .await
        .unwrap();
    let business = fixture::business(&mut admin).await;
    fixture::record(
        "configuration-static-try",
        serde_json::json!({"xid":current.xid(),"branch_id":current.branch_id().to_string(),"accepted":result.is_ok(),"fence_rows":count,"business":business,"original_receipt_retained":result.as_ref().err().and_then(|e|e.registered_branch()).is_some_and(|r|r.identity()==receipt.identity())}),
    );
    assert!(
        result.is_err(),
        "static Try must reject a branch with durable dynamic origin"
    );
    assert_eq!(
        result.unwrap_err().registered_branch().unwrap().identity(),
        receipt.identity()
    );
    assert_eq!(count, 0);
    assert!(business.is_empty());
    source.close().await.unwrap();
}

#[tokio::test]
#[ignore = "requires owned MySQL and configuration transition recovery"]
async fn static_callback_cannot_poison_manifest_only_origin_before_correct_configuration_recovers()
{
    let name = "static-callback";
    let (mut admin, source, dynamic, receipt, current) = manifest_only(name).await;
    let plain = Arc::new(
        MySqlTccResourceManager::new(
            source.clone(),
            "tcc-original-action".into(),
            Arc::new(fixture::Action::default()),
        )
        .unwrap(),
    );
    let listener = TcpListener::bind("127.0.0.1:0").await.unwrap();
    let (rm, store) = manager(plain, &listener, name).await;
    let id = current.clone();
    let server = tokio::spawn(async move {
        let mut socket = peer::bootstrap(&listener, id.resource().resource_id()).await;
        peer::callback(&mut socket, -490, &id, BranchPhase::Rollback).await
    });
    let response = server.await.unwrap();
    let state = store
        .lease(current.clone(), BranchPhase::Rollback)
        .await
        .unwrap()
        .state();
    let count: i64 = sqlx::query_scalar("SELECT COUNT(*) FROM seata_rs_tcc_fence_v1")
        .fetch_one(&mut admin)
        .await
        .unwrap();
    fixture::record(
        "configuration-static-callback",
        serde_json::json!({"stage":"static_attempt","xid":current.xid(),"branch_id":current.branch_id().to_string(),"result":format!("{:?}",response.0),"branch_status":response.1,"fence_rows":count,"journal":format!("{state:?}")}),
    );
    assert_eq!(
        response,
        (ResultCode::Failed, 9),
        "static callback must reject dynamic origin before journal or Fence writes"
    );
    assert!(state.is_none());
    assert_eq!(count, 0);
    rm.shutdown().await.unwrap();
    drop(store);
    let listener = TcpListener::bind("127.0.0.1:0").await.unwrap();
    let (rm, reopened) = manager(dynamic.clone(), &listener, name).await;
    let id = current.clone();
    let server = tokio::spawn(async move {
        let mut socket = peer::bootstrap(&listener, id.resource().resource_id()).await;
        peer::callback(&mut socket, -491, &id, BranchPhase::Rollback).await
    });
    assert_eq!(server.await.unwrap(), (ResultCode::Success, 8));
    assert_eq!(
        reopened
            .lease(receipt.identity().clone(), BranchPhase::Rollback)
            .await
            .unwrap()
            .state(),
        Some(BranchRecordState::Completed)
    );
    let row: (u8, u16, Vec<u8>) =
        sqlx::query_as("SELECT status,schema_version,application_data FROM seata_rs_tcc_fence_v1")
            .fetch_one(&mut admin)
            .await
            .unwrap();
    assert_eq!((row.0, row.1), (4, 2));
    assert_eq!(
        row.2,
        receipt.identity().application_data().unwrap().as_bytes()
    );
    assert!(dynamic
        .try_registered_with_context(&rm.client(), receipt.clone())
        .await
        .is_err());
    assert!(fixture::business(&mut admin).await.is_empty());
    fixture::record(
        "configuration-static-callback",
        serde_json::json!({"stage":"completed","xid":current.xid(),"branch_id":current.branch_id().to_string(),"static_result":"Failed","static_branch_status":9,"static_fence_rows":0,"static_journal":"None","journal":"Completed","status":4,"protocol":2,"original_application_data":receipt.identity().application_data(),"reported_application_data":current.application_data(),"late_try_rejected":true,"business":[]}),
    );
    rm.shutdown().await.unwrap();
    source.close().await.unwrap();
}
