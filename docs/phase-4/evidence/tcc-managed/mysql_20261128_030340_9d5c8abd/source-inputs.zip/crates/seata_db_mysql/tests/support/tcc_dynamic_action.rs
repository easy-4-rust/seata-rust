use super::fixture;
use seata_tcc::{BusinessActionContext, TccBusinessAction, TccError, TccTransaction};
use std::{future::Future, pin::Pin};
/// 真实 Try DML 后共享新参数；立即模式先报告一次，再由最终延迟路径报告后续变更。
/// 对应 Java: BusinessActionContextUtil#addContext 的测试业务扩展。
#[derive(Debug)]
pub struct TccDynamicAction {
    /// 是否在 Try 尚未返回时显式等待首次报告。
    pub immediate: bool,
}
impl TccBusinessAction for TccDynamicAction {
    fn try_action<'a>(
        &'a self,
        context: &'a BusinessActionContext,
        transaction: &'a mut dyn TccTransaction,
    ) -> Pin<Box<dyn Future<Output = Result<bool, TccError>> + Send + 'a>> {
        Box::pin(async move {
            fixture::Action::default()
                .try_action(context, transaction)
                .await
        })
    }
    fn try_action_with_context<'a>(
        &'a self,
        context: &'a mut BusinessActionContext,
        transaction: &'a mut dyn TccTransaction,
    ) -> Pin<Box<dyn Future<Output = Result<bool, TccError>> + Send + 'a>> {
        Box::pin(async move {
            fixture::Action::default()
                .try_action(context, transaction)
                .await?;
            let amount = serde_json::value::RawValue::from_string("9".into())
                .map_err(|_| TccError::Business)?;
            context.add_action_context("amount", Some(&amount))?;
            let precise =
                serde_json::value::RawValue::from_string("1.23000000000000000000000000001".into())
                    .map_err(|_| TccError::Business)?;
            context.add_action_context("precise", Some(&precise))?;
            if self.immediate {
                context.set_delay_report(Some(false));
                if !transaction.report_context(context).await? {
                    return Err(TccError::Business);
                }
                context.add_action_context("final", Some(&amount))?;
            }
            Ok(true)
        })
    }
    fn confirm<'a>(
        &'a self,
        context: &'a BusinessActionContext,
        transaction: &'a mut dyn TccTransaction,
    ) -> Pin<Box<dyn Future<Output = Result<bool, TccError>> + Send + 'a>> {
        Box::pin(async move {
            fixture::Action::default()
                .confirm(context, transaction)
                .await
        })
    }
    fn cancel<'a>(
        &'a self,
        context: &'a BusinessActionContext,
        transaction: &'a mut dyn TccTransaction,
    ) -> Pin<Box<dyn Future<Output = Result<bool, TccError>> + Send + 'a>> {
        Box::pin(async move {
            fixture::Action::default()
                .cancel(context, transaction)
                .await
        })
    }
}
