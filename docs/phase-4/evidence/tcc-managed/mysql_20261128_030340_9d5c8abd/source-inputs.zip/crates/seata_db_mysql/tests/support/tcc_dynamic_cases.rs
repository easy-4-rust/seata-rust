//! 原报告版本、旧 Pending 和合法新上下文回调的真实数据库验收。
#![allow(clippy::unwrap_used)]
use super::{fixture, manager, peer};
#[path = "tcc_dynamic_action.rs"]
mod action;
use seata_db_mysql::MySqlTccResourceManager;
use seata_protocol::{transaction::BranchRegisterRequest, BranchType, ResultCode};
use seata_rm::{BranchIdentity, BranchPhase, BranchRecordState, BranchResource};
use std::sync::Arc;
use tokio::net::TcpListener;

#[tokio::test]
#[ignore = "requires owned MySQL and explicit context-version migration"]
async fn full_context_reports_keep_original_receipt_and_recover_old_pending_with_new_callback() {
    let mut cases = Vec::new();
    for immediate in [false, true] {
        for phase in [BranchPhase::Commit, BranchPhase::Rollback] {
            let (mut admin, source, _) = fixture::seed().await;
            sqlx::raw_sql("DROP TABLE IF EXISTS seata_rs_tcc_context_v1")
                .execute(&mut admin)
                .await
                .unwrap();
            sqlx::raw_sql(include_str!(
                "../../migrations/020_seata_rs_tcc_context_v1.sql"
            ))
            .execute(&mut admin)
            .await
            .unwrap();
            let adapter = Arc::new(
                MySqlTccResourceManager::new(
                    source.clone(),
                    "tcc-original-action".into(),
                    Arc::new(action::TccDynamicAction { immediate }),
                )
                .unwrap()
                .with_context_reporting(),
            );
            let name = format!("dynamic-{immediate}-{phase:?}");
            let xid = format!("tcc:{name}");
            let branch = 9501;
            let original = BranchIdentity::new(
                xid.clone(),
                branch,
                adapter.key().clone(),
                Some(fixture::app(1)),
            )
            .unwrap();
            let listener = TcpListener::bind("127.0.0.1:0").await.unwrap();
            let (rm, store) = manager(adapter.clone(), &listener, &name).await;
            let id = original.clone();
            let (prepared, ready) = tokio::sync::oneshot::channel();
            let server = tokio::spawn(async move {
                let mut socket = peer::bootstrap(&listener, id.resource().resource_id()).await;
                peer::registered(
                    &mut socket,
                    id.resource().resource_id(),
                    id.xid(),
                    id.application_data(),
                    branch,
                )
                .await;
                if phase == BranchPhase::Commit {
                    assert_eq!(
                        peer::callback(&mut socket, -401, &id, phase).await,
                        (ResultCode::Success, 6)
                    );
                }
                prepared.send(()).unwrap();
                let mut reports = Vec::new();
                for _ in 0..if immediate { 2 } else { 1 } {
                    let (request, app) = peer::read_context_report(&mut socket, &id).await;
                    peer::reply_context_report(&mut socket, request, ResultCode::Success).await;
                    reports.push(app);
                }
                reports
            });
            let receipt = rm
                .client()
                .branch_register_with_receipt(BranchRegisterRequest {
                    xid: Some(xid),
                    branch_type: BranchType::Tcc,
                    resource_id: Some(adapter.key().resource_id().into()),
                    lock_key: None,
                    application_data: original.application_data().map(str::to_owned),
                })
                .await
                .unwrap();
            ready.await.unwrap();
            assert_eq!(
                store.lease(original.clone(), phase).await.unwrap().state(),
                if phase == BranchPhase::Commit {
                    Some(BranchRecordState::Pending)
                } else {
                    None
                }
            );
            let returned = adapter
                .try_registered_with_context(&rm.client(), receipt.clone())
                .await
                .unwrap();
            assert_eq!(returned.identity(), receipt.identity());
            let reports = server.await.unwrap();
            assert_eq!(reports.len(), if immediate { 2 } else { 1 });
            for app in &reports {
                assert!(app.contains("1.23000000000000000000000000001"));
            }
            assert_eq!(fixture::business(&mut admin).await, vec![(1, 7)]);
            rm.shutdown().await.unwrap();
            drop(store);
            let listener = TcpListener::bind("127.0.0.1:0").await.unwrap();
            let fresh = Arc::new(
                MySqlTccResourceManager::new(
                    source.clone(),
                    "tcc-original-action".into(),
                    Arc::new(fixture::Action::default()),
                )
                .unwrap()
                .with_context_reporting(),
            );
            let (fresh_rm, reopened) = manager(fresh, &listener, &name).await;
            let current = BranchIdentity::new(
                original.xid().into(),
                branch,
                original.resource().clone(),
                Some(reports.last().unwrap().clone()),
            )
            .unwrap();
            let server = tokio::spawn(async move {
                let mut socket = peer::bootstrap(&listener, current.resource().resource_id()).await;
                for request in [-402, -403] {
                    assert_eq!(
                        peer::callback(&mut socket, request, &current, phase).await,
                        (
                            ResultCode::Success,
                            if phase == BranchPhase::Commit { 5 } else { 8 }
                        )
                    );
                }
            });
            server.await.unwrap();
            assert_eq!(
                reopened
                    .lease(original.clone(), phase)
                    .await
                    .unwrap()
                    .state(),
                Some(BranchRecordState::Completed)
            );
            assert_eq!(
                fixture::business(&mut admin).await,
                if phase == BranchPhase::Commit {
                    vec![(1, 18)]
                } else {
                    vec![]
                }
            );
            let fence_data: Vec<u8> =
                sqlx::query_scalar("SELECT application_data FROM seata_rs_tcc_fence_v1")
                    .fetch_one(&mut admin)
                    .await
                    .unwrap();
            assert_eq!(fence_data, original.application_data().unwrap().as_bytes());
            let versions: i64 = sqlx::query_scalar("SELECT COUNT(*) FROM seata_rs_tcc_context_v1")
                .fetch_one(&mut admin)
                .await
                .unwrap();
            assert_eq!(versions, reports.len() as i64 + 1);
            fresh_rm.shutdown().await.unwrap();
            source.close().await.unwrap();
            cases.push(serde_json::json!({"immediate":immediate,"phase":format!("{phase:?}"),"xid":original.xid(),"branch_id":branch,"original_app":original.application_data(),"reports":reports,"old_pending":phase==BranchPhase::Commit,"journal":"Completed","versions":versions}));
        }
    }
    fixture::record(
        "dynamic-reports",
        serde_json::json!({"cases":cases,"whole_plan_complete":false}),
    );
}
