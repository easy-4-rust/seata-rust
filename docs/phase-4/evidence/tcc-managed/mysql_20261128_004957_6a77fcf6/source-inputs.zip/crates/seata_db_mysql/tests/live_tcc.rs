//! 正式 RM 与真实 MySQL 的 TCC 同事务 Fence 验收。
#![cfg(feature="tcc")]
#![allow(clippy::unwrap_used)]
#[path="support/tcc_managed_fixture.rs"]
mod fixture;
#[path="support/tcc_managed_peer.rs"]
mod peer;
use seata_db_mysql::MySqlTccResourceManager;
use seata_protocol::ResultCode;
use seata_rm::{BranchIdentity,BranchPhase,BranchRecordState,BranchResolution,BranchResource,FileBranchStore,JournalOptions,ResourceCatalog,ResourceManager};
use std::{sync::Arc,time::Duration};
use tokio::net::TcpListener;

async fn manager(adapter:Arc<MySqlTccResourceManager>,listener:&TcpListener,name:&str)->(ResourceManager,FileBranchStore){
    let catalog=ResourceCatalog::new(4,32767).unwrap();catalog.register(adapter).unwrap();
    let store=FileBranchStore::open(fixture::folder(name).join("branches.log"),JournalOptions::new(32,1048576,65536,32).unwrap()).await.unwrap();
    let manager=ResourceManager::builder(fixture::pool(listener.local_addr().unwrap()),fixture::registration(false),catalog,store.clone()).request_timeout(Duration::from_secs(3)).callback_timeout(Duration::from_secs(5)).build().unwrap();
    (manager,store)
}

#[tokio::test]
#[ignore="requires owned MySQL and explicit TCC Fence schema"]
async fn original_tcc_try_and_terminal_effects_are_atomic_and_idempotent(){
    let (mut admin,source,adapter)=fixture::seed().await;
    let mut proofs=Vec::new();
    for (index,phase) in [BranchPhase::Commit,BranchPhase::Rollback].into_iter().enumerate(){
        let listener=TcpListener::bind("127.0.0.1:0").await.unwrap();
        let (rm,store)=manager(adapter.clone(),&listener,&format!("normal-{index}")).await;
        let xid=format!("tcc:managed:{index}");let branch=9007199254740995+index as i64;let app=fixture::app(index as i64+1);
        let identity=BranchIdentity::new(xid.clone(),branch,adapter.key().clone(),Some(app.clone())).unwrap();
        let original=identity.clone();
        let (start,ready)=tokio::sync::oneshot::channel();
        let server=tokio::spawn(async move {
            let mut socket=peer::bootstrap(&listener,original.resource().resource_id()).await;
            peer::registered(&mut socket,original.resource().resource_id(),original.xid(),original.application_data(),branch).await;
            ready.await.unwrap();
            let expected=if phase==BranchPhase::Commit{5}else{8};
            for id in [1,2]{assert_eq!(peer::callback(&mut socket,id,&original,phase).await,(ResultCode::Success,expected));}
        });
        let receipt=adapter.register_and_try(&rm.client(),&xid,Some(app)).await.unwrap();
        assert_eq!(receipt.identity(),&identity);assert_eq!(receipt.lock_key(),None);
        let state:u8=sqlx::query_scalar("SELECT status FROM seata_rs_tcc_fence_v1 WHERE xid=? AND branch_id=?").bind(xid.as_bytes()).bind(branch).fetch_one(&mut admin).await.unwrap();
        assert_eq!(state,1);
        assert!(fixture::business(&mut admin).await.contains(&(index as i32+1,7)));
        let duplicate=adapter.try_registered(receipt.clone()).await.unwrap_err();assert_eq!(duplicate.registered_branch().unwrap().identity(),&identity);
        start.send(()).unwrap();server.await.unwrap();
        assert_eq!(store.lease(identity.clone(),phase).await.unwrap().state(),Some(BranchRecordState::Completed));
        let state:u8=sqlx::query_scalar("SELECT status FROM seata_rs_tcc_fence_v1 WHERE xid=? AND branch_id=?").bind(xid.as_bytes()).bind(branch).fetch_one(&mut admin).await.unwrap();
        assert_eq!(state,if phase==BranchPhase::Commit{2}else{3});
        let opposite=if phase==BranchPhase::Commit{BranchPhase::Rollback}else{BranchPhase::Commit};
        assert_eq!(adapter.recover(&identity,opposite).await.unwrap(),BranchResolution::Unknown);
        proofs.push(serde_json::json!({"xid":xid,"branch_id":branch.to_string(),"status":state,"journal":"Completed","duplicate_try_rejected":true}));
        rm.shutdown().await.unwrap();
    }
    assert_eq!(fixture::business(&mut admin).await,vec![(1,14)]);
    fixture::record("normal",serde_json::json!({"branches":proofs,"business":[[1,14]]}));
    source.close().await.unwrap();
}
