//! WP07 既有正式事件的静态模板与字段值校验，不接纳应用自定义内容。
use std::collections::BTreeMap;
use tracing::Metadata;

pub(crate) fn known_target(target:&str)->bool{matches!(target,"seata_tm::rpc"|"seata_rm::rpc"|"seata_rm::callback"|"seata_rm::callback_write"|"seata_db_mysql::control"|"seata_db_mysql::undo")}

// 此第一阶段实现先按 target 选择模板；元数据字段集合的前置校验由目标 RED 测试驱动补齐。
pub(crate) fn expected_message(meta:&Metadata<'_>)->Option<&'static str>{
    match meta.target(){
        "seata_tm::rpc"=>Some("tm_rpc_outcome"),
        "seata_rm::rpc"=>Some("rm_rpc_outcome"),
        "seata_rm::callback"=>Some("rm_callback_decision"),
        "seata_rm::callback_write"=>Some("rm_callback_response_write"),
        "seata_db_mysql::control"=>Some("mysql_control_outcome"),
        "seata_db_mysql::undo" if meta.fields().field("resource_digest").is_some()=>Some("mysql_undo_checksum_rejected"),
        "seata_db_mysql::undo"=>Some("mysql_undo_outcome"),
        _=>None,
    }
}
fn optional(value:&str)->&str{value.strip_prefix("Some(").and_then(|s|s.strip_suffix(')')).unwrap_or(value)}
fn digest(value:&str)->bool {let value=optional(value).trim_matches('"');value.len()==64&&value.bytes().all(|b|b.is_ascii_digit()||(b'a'..=b'f').contains(&b))}
fn signed_id(value:&str,branch:bool)->bool {
    if value=="None"{return true;}
    let value=optional(value);
    if branch{value.parse::<i64>().is_ok_and(|n|n>0)}else{value.parse::<i32>().is_ok()}
}
pub(crate) fn valid_values(target:&str,fields:&BTreeMap<String,String>,message:&str)->bool {
    fields.get("message").is_some_and(|v|v==message)&&fields.iter().all(|(key,value)|match key.as_str(){
        "message"=>value==message,
        "xid"=>!value.is_empty(),
        "request_id"=>signed_id(value,false),
        "branch_id"=>signed_id(value,true),
        "resource_digest"=>digest(value),
        "resource_sha256"=>digest(value)||((value=="None"&&target=="seata_rm::rpc")||(value.is_empty()&&target=="seata_db_mysql::undo")),
        "connection_generation"|"response_count"=>value.parse::<u64>().is_ok_and(|v|v>0),
        "outcome"=>matches!(value.as_str(),"response"|"unknown"|"not_sent"|"local_written"|"cancelled"|"completed"|"unknown_commit"|"before_commit_error"),
        "observation"=>matches!(value.as_str(),"consumed"|"fenced_inserted"|"fenced_existing"|"undo_present"|"not_observed"),
        "resolution"=>matches!(value.as_str(),"applied"|"unresolved"|"not_observed"),
        "commit_attempted"=>matches!(value.as_str(),"true"|"false"),
        "requested_phase"=>matches!(value.as_str(),"none"|"commit"|"rollback"),
        "phase"=>matches!(value.as_str(),"Commit"|"Rollback"),
        "result_code"=>matches!(value.as_str(),"Success"|"Failed"),
        "branch_status"=>matches!(value.as_str(),"PhaseTwoCommitted"|"PhaseTwoRollbacked"|"PhaseTwoCommitFailedRetryable"|"PhaseTwoCommitFailedUnretryable"|"PhaseTwoRollbackFailedRetryable"|"PhaseTwoRollbackFailedUnretryable"),
        "operation"=>match target{
            "seata_tm::rpc"=>matches!(value.as_str(),"Begin"|"Commit"|"Rollback"|"Status"),
            "seata_rm::rpc"=>matches!(value.as_str(),"BranchRegister"|"BranchReport"|"LockQuery"),
            "seata_db_mysql::control"=>matches!(value.as_str(),"enroll"|"bind_commit"|"bind_rollback"|"commit"|"rollback"|"observe"),
            "seata_db_mysql::undo"=>matches!(value.as_str(),"rollback"|"fence"),
            _=>false,
        },
        _=>false,
    })
}
