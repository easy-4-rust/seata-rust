//! 调用方独占文件能力上的真实单文件输出及失败边界。
#![cfg(feature = "structured_log_file")]
#![allow(clippy::unwrap_used)]
use seata_observability::{StructuredLogConfig, StructuredLogFileConfig, StructuredLogFileError,
    StructuredLogFileShutdown, StructuredLogFileSink, StructuredLogFileStage, StructuredLogSubscriber};
use std::{fs::{File,OpenOptions},path::PathBuf,sync::atomic::{AtomicU64,Ordering},time::Duration};

struct Fixture(PathBuf);
impl Fixture {
    fn new() -> (Self, File) {
        static NEXT:AtomicU64=AtomicU64::new(0);
        let path=std::env::temp_dir().join(format!("seata-private-file-{}-{}.ndjson",std::process::id(),NEXT.fetch_add(1,Ordering::Relaxed)));
        let file=OpenOptions::new().create_new(true).write(true).read(true).open(&path).unwrap();
        (Self(path),file)
    }
    fn bytes(&self)->Vec<u8>{std::fs::read(&self.0).unwrap()}
}
impl Drop for Fixture {fn drop(&mut self){let _=std::fs::remove_file(&self.0);}}
fn config()->StructuredLogFileConfig {StructuredLogFileConfig::new(65536,64,Duration::from_secs(60)).unwrap()}
fn channel()->(StructuredLogSubscriber,seata_observability::StructuredLogReceiver,seata_observability::StructuredLogSampler){StructuredLogSubscriber::channel(StructuredLogConfig::new(8,4096).unwrap())}
fn emit(subscriber:&StructuredLogSubscriber,id:i64){
    tracing::subscriber::with_default(subscriber.clone(),||{
        tracing::info!(target:"seata_tm::rpc",operation="Status",xid="tc:file",request_id=id,outcome="response","tm_rpc_outcome");
    });
}

#[cfg(windows)]
#[tokio::test]
async fn readonly_empty_target_exercises_native_sync_all() {
    let (fixture,file)=Fixture::new();drop(file);
    let readonly=File::open(&fixture.0).unwrap();
    let (subscriber,receiver,_)=channel();drop(subscriber);
    let mut sink=StructuredLogFileSink::start(receiver,readonly,config()).unwrap();
    let error=sink.wait().await.expect_err("read-only target must exercise native sync_all");
    match error {
        StructuredLogFileError::Io{stage,kind,os_error,progress,current_record_may_be_partial}=>{
            assert_eq!(stage,StructuredLogFileStage::Sync);assert_eq!(kind,std::io::ErrorKind::PermissionDenied);assert_eq!(os_error,Some(5));
            assert_eq!(progress.written_records,0);assert_eq!(progress.synchronized_records,0);assert_eq!(progress.sync_operations,0);assert!(!current_record_may_be_partial);
        },other=>panic!("unexpected native failure: {other:?}"),
    }
    assert!(fixture.bytes().is_empty());
}
