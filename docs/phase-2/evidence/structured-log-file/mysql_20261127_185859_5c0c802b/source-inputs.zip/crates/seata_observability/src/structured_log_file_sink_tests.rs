//! 运行时取消不等于成功关闭，不开放生产 abort 权限。
#![allow(clippy::unwrap_used)]
use crate::{
    StructuredLogConfig, StructuredLogFileConfig, StructuredLogFileError, StructuredLogFileSink,
    StructuredLogSubscriber,
};
use std::{fs::OpenOptions, time::Duration};

#[tokio::test]
async fn cancelled_worker_reports_unknown_and_caches_it() {
    let path = std::path::PathBuf::from("D:/Temp").join(format!(
        "seata-file-cancel-{}-{}.ndjson",
        std::process::id(),
        std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .unwrap()
            .as_nanos()
    ));
    let file = OpenOptions::new()
        .write(true)
        .create_new(true)
        .open(&path)
        .unwrap();
    let (_subscriber, receiver, _) =
        StructuredLogSubscriber::channel(StructuredLogConfig::new(2, 4096).unwrap());
    let mut sink = StructuredLogFileSink::start(
        receiver,
        file,
        StructuredLogFileConfig::new(4096, 64, Duration::from_secs(60)).unwrap(),
    )
    .unwrap();
    sink.worker.as_ref().unwrap().abort();
    let error = sink.wait().await.unwrap_err();
    assert!(
        matches!(error, StructuredLogFileError::WorkerOutcomeUnknown { .. }),
        "cancelled worker claimed known completion"
    );
    assert_eq!(sink.wait().await, Err(error));
    std::fs::remove_file(path).unwrap();
}
