//! 官方 Layer 组合保持应用过滤及 span 生命周期，Seata 只输出自身固定字段。
#![cfg(feature="structured_log_layer")]
#![allow(clippy::unwrap_used)]
use seata_observability::{StructuredLogConfig,StructuredLogSubscriber};
use std::{collections::BTreeMap,sync::{Arc,Mutex,atomic::{AtomicBool,Ordering}}};
use tracing::{Event,Subscriber,span::{Attributes,Id,Record}};
use tracing_subscriber::{Layer,layer::{Context,SubscriberExt},registry::{Registry,LookupSpan},filter::filter_fn};

#[derive(Default)]
struct AppState {events:Vec<(String,Option<u64>,BTreeMap<String,String>)>,opened:Vec<u64>,closed:Vec<u64>,entered:usize,exited:usize,recorded:usize,follows:Vec<(u64,u64)>}
#[derive(Clone)]
struct AppLayer(Arc<Mutex<AppState>>);
impl<S> Layer<S> for AppLayer where S:Subscriber,for<'a>S:LookupSpan<'a>{
    fn on_new_span(&self,_attrs:&Attributes<'_>,id:&Id,_ctx:Context<'_,S>){self.0.lock().unwrap().opened.push(id.into_u64());}
    fn on_record(&self,_id:&Id,_record:&Record<'_>,_ctx:Context<'_,S>){self.0.lock().unwrap().recorded+=1;}
    fn on_follows_from(&self,id:&Id,from:&Id,_ctx:Context<'_,S>){self.0.lock().unwrap().follows.push((id.into_u64(),from.into_u64()));}
    fn on_enter(&self,_id:&Id,_ctx:Context<'_,S>){self.0.lock().unwrap().entered+=1;}
    fn on_exit(&self,_id:&Id,_ctx:Context<'_,S>){self.0.lock().unwrap().exited+=1;}
    fn on_close(&self,id:Id,_ctx:Context<'_,S>){self.0.lock().unwrap().closed.push(id.into_u64());}
    fn on_event(&self,event:&Event<'_>,ctx:Context<'_,S>){let mut fields=BTreeMap::new();event.record(&mut |field:&tracing::field::Field,value:&dyn std::fmt::Debug|{fields.insert(field.name().into(),format!("{value:?}"));});let parent=ctx.event_span(event).map(|s|s.id().into_u64());self.0.lock().unwrap().events.push((event.metadata().target().into(),parent,fields));}
}
fn app_event(){tracing::info!(target:"app::composition",payload="application-private-payload","application event");}
fn seata_event(){tracing::info!(target:"seata_tm::rpc",operation="Status",xid="tc:layer",request_id=-17,outcome="response","tm_rpc_outcome");}
#[tokio::test]
async fn dynamic_application_filter_keeps_disabled_spans_and_independent_seata_events(){
    let(subscriber,mut receiver,sampler)=StructuredLogSubscriber::channel(StructuredLogConfig::new(8,4096).unwrap());let enabled=Arc::new(AtomicBool::new(false));let state=Arc::new(Mutex::new(AppState::default()));let selected=enabled.clone();
    let stack=Registry::default().with(AppLayer(state.clone()).with_filter(filter_fn(move |meta|meta.target().starts_with("app::")&&selected.load(Ordering::SeqCst)))).with(subscriber.into_layer());
    tracing::subscriber::with_default(stack,||{
        let off=tracing::info_span!(target:"app::composition","disabled-application",password="private-disabled-span");assert!(off.is_disabled(),"Seata layer enabled a filtered application span");app_event();seata_event();
        enabled.store(true,Ordering::SeqCst);app_event();
        enabled.store(false,Ordering::SeqCst);app_event();
    });assert_eq!(state.lock().unwrap().events.len(),1,"application event missing from sibling layer");assert_eq!(state.lock().unwrap().opened.len(),0);assert_eq!(sampler.snapshot().accepted,1);
    let bytes=receiver.recv().await.unwrap();let value:serde_json::Value=serde_json::from_slice(&bytes).unwrap();assert_eq!(value["fields"]["request_id"],"-17");assert!(!String::from_utf8(bytes).unwrap().contains("application-private"));assert!(receiver.recv().await.is_none());
}
#[tokio::test]
async fn application_span_records_follows_clone_context_and_final_close_are_preserved(){
    let(subscriber,mut receiver,sampler)=StructuredLogSubscriber::channel(StructuredLogConfig::new(8,4096).unwrap());let state=Arc::new(Mutex::new(AppState::default()));
    let stack=Registry::default().with(AppLayer(state.clone())).with(subscriber.into_layer());
    let (root_id,child_id)=tracing::subscriber::with_default(stack,||{
        let root=tracing::info_span!(target:"app::composition","application-root",password="private-span-password",progress=tracing::field::Empty);let root_id=root.id().unwrap().into_u64();let clone=root.clone();root.record("progress",7_i64);
        let child={let _entered=root.enter();let child=tracing::info_span!(target:"app::composition","application-child");let _child_entered=child.enter();assert_eq!(tracing::Span::current().id(),child.id());app_event();seata_event();drop(_child_entered);child};let child_id=child.id().unwrap().into_u64();child.follows_from(root.id());drop(child);drop(root);assert!(!state.lock().unwrap().closed.contains(&root_id),"span closed before last clone");drop(clone);(root_id,child_id)
    });
    let state=state.lock().unwrap();assert_eq!(state.opened.len(),2);assert!(state.closed.contains(&root_id)&&state.closed.contains(&child_id));assert_eq!(state.closed.len(),2);assert_eq!(state.recorded,1);assert_eq!(state.entered,state.exited);assert!(state.entered>=2);assert_eq!(state.follows,vec![(child_id,root_id)]);assert_eq!(state.events.len(),2);assert!(state.events.iter().all(|e|e.1==Some(child_id)));drop(state);
    let bytes=receiver.recv().await.unwrap();let text=String::from_utf8(bytes).unwrap();assert!(!text.contains("private-span-password")&&!text.contains("application-private-payload"));assert_eq!(sampler.snapshot().accepted,1);assert!(receiver.recv().await.is_none());
}
