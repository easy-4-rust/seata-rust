# seata-rm — WP04 资源管理与持久恢复

已实现 `ResourceCatalog`、`BranchResource`、`BranchDispatcher` 及 `FileBranchStore`。本组件按精确资源模式/ID分派，先同步 Pending 再执行资源，未决记录先恢复查询，完成记录同步后才返回完成状态。多个分派器通过共享 Store 的分支租约串行；取消后的磁盘任务继续持有排他权和预算，同租约后续写入也须等旧写真正结束。

文件显式传入，版本头为 `SRMJNL01`，记录绑定递增序号、状态、原生V1分支请求和CRC32。打开时取得合作式整文件独占锁，严格检查身份、方向、迁移、容量和完整性。损坏、残尾、超限或写入/同步错误不被解释为资源成功，也不会自动截断或驱逐去重记录。文件父目录须已存在；日志应由同一资源管理实例独占。

`BranchResource::recover` 必须提供资源级事实。`NotApplied` 要求所有旧尝试均不可能迟到生效；仅查不到效果行不够。`Unknown` 或错误保持 Pending。日志不是数据库效果与Undo的原子提交证明；具体数据库适配器仍待 WP05/06。进程测试使用绑定原始身份的文件效果夹具，仅验证通用恢复契约。

`ResourceManager::builder` 拥有原生登记连接池、有限回调工作任务和关闭顺序；`client()` 返回可克隆的 `ResourceClient`，提供一次性的 `branch_register`、`branch_report`、`lock_query`。返回完整响应；`RmCallError` 区分本地未发送、TC明确Failed、协议失败与发送后未知，并保留原请求。BranchReport的Java可选资源字段保持None，lockable=false是成功观察结果，Failed响应中的true不能覆盖错误。未知分支注册不会补造编号或自动重发。

回调保留原连接、signed请求编号和可空有序头；整批平坦消息先校验，再分派资源。回调总期限在校验前建立，字段按借用先检查边界再复制；矛盾方向和不支持的子消息不会先执行前面的资源。原登记契约不变：初始化期间缓存回调，完整资源修订接受后才转发和发送业务帧。Drop同步关闭所有调用入口；shutdown取消/join资源任务和网络监督器，保留清理panic，并等待有界磁盘排空，失败不能报告完整清理成功。

[运行组件验证](../../docs/phase-1/evidence/rm-runtime/README.md)在Rust1.99/最低1.85各执行45RM＋189已有组件测试及11隔离削弱检查，覆盖动态资源就绪、旧代际晚完成、批次、超时、关闭panic和真实恢复子进程。[完整首期WP04验收](../../docs/phase-1/evidence/rm-gate/README.md)现已通过：另有原JavaTC正常/重复/重连各提交回滚六例、38观察单测、10观察器削弱检查及双版本2项辅助资源测试；真实TC重试不重复资源效果，原未知不被迟到响应或Finished改写。SQL/Undo属于后续WP05/06，尚未实现。规格事实源仍为原 [WP04验收清单](../../docs/phase-0/v1-implementation-acceptance-checklist.md) 与 [RM实施契约](../../docs/phase-0/tm-tc-rm-call-chains.md)。外部TC风险未接受，共享锁问题暂缓，后续全部计划保留。

验证：`cargo test --locked --offline -p seata-rm --all-targets`。测试文件及子进程证据均写入 D 盘专属目录。默认忽略的 `journal_process_child` 是父测试真实启动的子进程入口，不单独计作正式测试。


## 只读日志与分派指标

FileBranchStore::metrics_sampler 和 ResourceManager::metrics_sampler 签发 RmMetricsSampler，只持有固定原子计数，不持有日志文件、租约或资源分派能力。按 BranchPhase 读取 RmBranchMetrics，区分保留日志的四种状态 gauge，以及同一日志打开周期内的分派结果、取消、错误、复用和 apply/recover 尝试 counter。同日志的手工分派和正式回调共享计数；重开日志时从校验后的记录重建 gauge，分派累计归零。保留旧采样器不阻止原文件再次打开。

Completed gauge 表示已同步的保留日志条目，不等于 TC 活跃分支数或 SQL/Undo 的原子性证明。分派取消后后台磁盘任务仍可能完成，gauge 可以随后更新；取消只记 cancelled，不推断资源未执行。journal_faulted 表示追加写入/同步失败，此时仅保留最后确认的 gauge；journal_closed 表示所有者进入销毁，不是文件锁释放证明。并发快照逐字段采样，累计饱和不回绕。

seata-observability 的 with_rm_branches 导出固定 34 条 RM 序列。双版本测试、写入前误发布的失败对照、原 TC/MySQL 停机恢复及重叠回调证据见 [RM 指标验收](../../docs/phase-2/evidence/rm-branch-metrics/README.md)。完整生产指标、告警及部署门槛继续。


## 只读出站调用指标

ResourceManager::call_metrics_sampler 与 ResourceClient::call_metrics_sampler 返回 RmCallMetricsSampler，按三种 RmOperation 读取 RmOperationMetrics。同管理器全部客户端克隆共享固定计数，注册回执只计一次；重建管理器归零。active 为在途调用，结果区分 observed、tc_rejected、unknown、not_sent、local_rejected、cancelled，protocol_errors 为可重叠的附加计数。LockQuery 成功响应中的 false 仍计 observed；取消不证明请求未发送。管理器关闭后保留客户端的本地调用仍可增加计数。

采样器不保留通讯或资源能力，with_rm_calls 可导出固定 24 条序列。接口、默认功能与 Java 可选字段语义保持兼容。见 [双版本调用指标证据](../../docs/phase-2/evidence/rm-call-metrics/README.md)。
