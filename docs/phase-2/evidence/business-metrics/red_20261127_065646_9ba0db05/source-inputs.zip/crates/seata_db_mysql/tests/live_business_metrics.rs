//! 真实业务 DML/显式回滚计数；指标成功不替代数据库提交事实。
#![allow(clippy::unwrap_used)]
#[path = "support/owned_mysql.rs"]
mod owned_mysql;
use seata_at::SqlRecognizerFactory;
use seata_datasource::FieldValue;
use seata_db_mysql::{DbError, MySqlDataSource, MySqlPhaseOneOperation as Op, MySqlPhaseOneOutcome as Out};
use std::time::Duration;

async fn seed() -> (sqlx::MySqlConnection, MySqlDataSource) {
    let mut admin = owned_mysql::admin().await;
    sqlx::query("DROP TABLE IF EXISTS business_metrics").execute(&mut admin).await.unwrap();
    sqlx::query("CREATE TABLE business_metrics(id INT PRIMARY KEY,v INT NOT NULL) ENGINE=InnoDB").execute(&mut admin).await.unwrap();
    sqlx::query("INSERT INTO business_metrics VALUES(1,10)").execute(&mut admin).await.unwrap();
    let source=MySqlDataSource::connect(owned_mysql::options(None).operation_timeout(Duration::from_secs(3)).unwrap()).await.unwrap();
    (admin,source)
}
async fn value(admin: &mut sqlx::MySqlConnection) -> i32 {
    sqlx::query_scalar("SELECT v FROM business_metrics WHERE id=1").fetch_one(admin).await.unwrap()
}
fn save(name: &str, data: serde_json::Value) {
    let root=std::path::PathBuf::from(std::env::var_os("SEATA_BUSINESS_METRICS_OUT").unwrap());
    std::fs::create_dir_all(&root).unwrap();
    std::fs::write(root.join(name),serde_json::to_vec_pretty(&data).unwrap()).unwrap();
}
#[tokio::test]
#[ignore = "requires owned real MySQL fixture"]
async fn completed_dml_is_not_committed_and_delegated_rollback_counts_once() {
    let (mut admin,source)=seed().await;
    let clone=source.clone();let metrics=source.phase_one_metrics_sampler();
    let mut tx=clone.begin().await.unwrap();
    let update=SqlRecognizerFactory::recognize("UPDATE business_metrics SET v=? WHERE id=1").unwrap();
    let never=tx.execute(&update,&[]);drop(never);
    assert_eq!(metrics.snapshot(Op::Execute),Default::default());
    assert_eq!(tx.execute(&update,&[FieldValue::Signed(11)]).await.unwrap(),1);
    assert_eq!(metrics.snapshot(Op::Execute).count(Out::ExecutionCompleted),1,"business DML settlement missing");
    let insert=SqlRecognizerFactory::recognize("INSERT INTO business_metrics(id,v) VALUES(2,20)").unwrap();
    assert_eq!(tx.execute(&insert,&[]).await.unwrap(),1);
    let delete=SqlRecognizerFactory::recognize("DELETE FROM business_metrics WHERE id=2").unwrap();
    assert_eq!(tx.execute(&delete,&[]).await.unwrap(),1);
    let zero=SqlRecognizerFactory::recognize("DELETE FROM business_metrics WHERE id=999").unwrap();
    assert_eq!(tx.execute(&zero,&[]).await.unwrap(),0);
    assert_eq!(value(&mut admin).await,10,"DML success is not commit");
    tx.rollback().await.unwrap();
    assert_eq!(value(&mut admin).await,10);
    assert_eq!(metrics.snapshot(Op::Execute).count(Out::ExecutionCompleted),4);
    assert_eq!(clone.phase_one_metrics_sampler().snapshot(Op::Rollback).count(Out::RollbackConfirmed),1);
    // 自动 Drop 仅释放原事务，不伪造一次显式 rollback API。
    drop(source.begin().await.unwrap());
    assert_eq!(metrics.snapshot(Op::Rollback).count(Out::RollbackConfirmed),1);
    source.close().await.unwrap();
    assert!(Op::ALL.iter().all(|op|metrics.snapshot(*op).active==0));
    save("completed.json",serde_json::json!({"completed":metrics.snapshot(Op::Execute).count(Out::ExecutionCompleted),"rollback_confirmed":metrics.snapshot(Op::Rollback).count(Out::RollbackConfirmed),"visible_value":10,"active":0}));
}
#[tokio::test]
#[ignore = "requires owned real MySQL fixture"]
async fn input_and_driver_errors_keep_the_original_transaction_uncommitted() {
    let (mut admin,source)=seed().await;let metrics=source.phase_one_metrics_sampler();
    let mut tx=source.begin().await.unwrap();
    let update=SqlRecognizerFactory::recognize("UPDATE business_metrics SET v=? WHERE id=1").unwrap();
    assert!(tx.execute(&update,&[]).await.is_err());
    assert_eq!(metrics.snapshot(Op::Execute).count(Out::ExecutionFailed),1);
    assert_eq!(tx.execute(&update,&[FieldValue::Signed(12)]).await.unwrap(),1);
    let duplicate=SqlRecognizerFactory::recognize("INSERT INTO business_metrics(id,v) VALUES(1,50)").unwrap();
    assert!(matches!(tx.execute(&duplicate,&[]).await,Err(DbError::Driver {code:Some(1062),..})));
    assert!(matches!(tx.execute(&update,&[FieldValue::Signed(13)]).await,Err(DbError::Poisoned)));
    tx.rollback().await.unwrap();
    assert_eq!(value(&mut admin).await,10);
    assert_eq!(metrics.snapshot(Op::Execute).count(Out::ExecutionFailed),3);
    assert_eq!(metrics.snapshot(Op::Execute).count(Out::ExecutionCompleted),1);
    assert_eq!(metrics.snapshot(Op::Rollback).count(Out::RollbackConfirmed),1);
    source.close().await.unwrap();
    save("errors.json",serde_json::json!({"failed":3,"completed":1,"rollback_confirmed":1,"visible_value":10}));
}
#[tokio::test]
#[ignore = "requires owned real MySQL fixture"]
async fn blocked_dml_cancellation_and_deadline_are_not_successful_execution() {
    let (mut admin,source)=seed().await;let metrics=source.phase_one_metrics_sampler();
    sqlx::query("START TRANSACTION").execute(&mut admin).await.unwrap();
    sqlx::query("UPDATE business_metrics SET v=10 WHERE id=1").execute(&mut admin).await.unwrap();
    let clone=source.clone();
    let task=tokio::spawn(async move {let mut tx=clone.begin().await.unwrap();let sql=SqlRecognizerFactory::recognize("UPDATE business_metrics SET v=20 WHERE id=1").unwrap();tx.execute(&sql,&[]).await});
    let mut observer=owned_mysql::admin().await;
    let limit=tokio::time::Instant::now()+Duration::from_secs(2);
    let waits=loop {
        let waits:i64=sqlx::query_scalar("SELECT COUNT(*) FROM performance_schema.data_lock_waits w JOIN performance_schema.data_locks l ON w.REQUESTING_ENGINE_LOCK_ID=l.ENGINE_LOCK_ID WHERE l.OBJECT_SCHEMA=DATABASE() AND l.OBJECT_NAME='business_metrics'").fetch_one(&mut observer).await.unwrap();
        if waits>0 {break waits;}
        assert!(tokio::time::Instant::now()<limit,"real business row wait missing");
        tokio::time::sleep(Duration::from_millis(10)).await;
    };
    assert_eq!(metrics.snapshot(Op::Execute).active,1);
    task.abort();assert!(task.await.unwrap_err().is_cancelled());
    assert_eq!(metrics.snapshot(Op::Execute).active,0);
    assert_eq!(metrics.snapshot(Op::Execute).count(Out::Cancelled),1);
    let mut tx=source.begin().await.unwrap();let sql=SqlRecognizerFactory::recognize("UPDATE business_metrics SET v=30 WHERE id=1").unwrap();
    assert!(matches!(tx.execute(&sql,&[]).await,Err(DbError::Deadline {..})));
    assert!(matches!(tx.rollback().await,Err(DbError::Closed)));
    assert_eq!(metrics.snapshot(Op::Rollback).count(Out::RollbackUnconfirmed),1);
    sqlx::query("ROLLBACK").execute(&mut admin).await.unwrap();
    assert_eq!(value(&mut admin).await,10);
    assert_eq!(metrics.snapshot(Op::Execute).count(Out::ExecutionFailed),1);
    assert_eq!(metrics.snapshot(Op::Execute).count(Out::ExecutionCompleted),0);
    assert_eq!(metrics.snapshot(Op::Execute).count(Out::Cancelled),1);
    source.close().await.unwrap();
    save("waits.json",serde_json::json!({"real_row_waits":waits,"cancelled":1,"failed":1,"completed":0,"rollback_unconfirmed":1,"visible_value":10,"active":0}));
}
