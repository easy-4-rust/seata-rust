//! 恢复控制事件只陈述本次调用结果，不把终态观察当成重复业务效果。
#![allow(clippy::unwrap_used, clippy::expect_used)]
#[path = "support/undo_store_fixture.rs"]
#[allow(dead_code)]
mod fixture;
#[path = "support/owned_mysql.rs"]
mod owned_mysql;
#[path = "support/rm_recovery_fixture.rs"]
#[allow(dead_code)]
mod recovery;
#[path = "../../seata_rm/tests/support/rm_peer.rs"]
mod rm_fixture;
#[path = "support/undo_rollback_fixture.rs"]
mod rollback_fixture;
#[path = "support/java_checksum_events.rs"]
mod event_capture;
use seata_rm::{BranchPhase,BranchResolution,BranchResource};
use std::{collections::BTreeMap,sync::{Arc,Mutex}};
use sha2::{Digest,Sha256};

fn selected(events: &Arc<Mutex<Vec<BTreeMap<String,String>>>>) -> Vec<BTreeMap<String,String>> {
    events.lock().unwrap().iter().filter(|row|row.get("target").is_some_and(|target|target=="seata_db_mysql::control")).cloned().collect()
}
fn check(events: &[BTreeMap<String,String>],resource: &str) {
    let fields=["target","message","operation","xid","branch_id","resource_sha256","outcome","resolution","commit_attempted"];
    for event in events {
        assert_eq!(event.len(),fields.len());assert!(fields.iter().all(|name|event.contains_key(*name)));
        assert_eq!(event["target"],"seata_db_mysql::control");assert_eq!(event["message"],"mysql_control_outcome");
        assert_eq!(event["xid"],"rollback:xid");assert_eq!(event["branch_id"],"42");assert_eq!(event["resource_sha256"],format!("{:x}",Sha256::digest(resource.as_bytes())));
        let text=format!("{event:?}");for secret in ["event-secret-value","seata-mysql-fixture-only","INSERT INTO","jdbc:mysql", "application-data-private"] {assert!(!text.contains(secret));}
    }
}
#[tokio::test]
#[ignore = "requires owned real MySQL fixture"]
async fn real_control_writes_and_duplicate_reads_emit_distinct_commit_boundaries() {
    let (mut admin,source)=rollback_fixture::seed(&[],&["INSERT INTO undo_work(id,v) VALUES(1,'event-secret-value')"],seata_at::MySqlJdbcProfile::Connector8Default,None).await;
    recovery::schema(&mut admin).await;let adapter=recovery::adapter(source.clone());let receipt=recovery::receipt(adapter.clone(),Some("application-data-private")).await;
    let events=Arc::new(Mutex::new(Vec::new()));let _capture=tracing::subscriber::set_default(event_capture::EventCapture(events.clone()));
    let never=adapter.enroll(&receipt);drop(never);assert!(selected(&events).is_empty());
    adapter.enroll(&receipt).await.unwrap();
    let values=selected(&events);assert_eq!(values.len(),1,"missing real MySQL control event");
    assert_eq!(values[0]["operation"],"enroll");assert_eq!(values[0]["outcome"],"completed");assert_eq!(values[0]["resolution"],"unresolved");assert_eq!(values[0]["commit_attempted"],"true");
    assert_eq!(adapter.apply(receipt.identity(),BranchPhase::Rollback).await.unwrap(),BranchResolution::Applied);
    assert_eq!(adapter.recover(receipt.identity(),BranchPhase::Rollback).await.unwrap(),BranchResolution::Applied);
    assert_eq!(fixture::count(&mut admin,"undo_work").await,0);assert_eq!(recovery::state(&mut admin).await,(1,2,1));
    source.close().await.unwrap();let values=selected(&events);check(&values,adapter.key().resource_id());
    let boundaries:Vec<_>=values.iter().map(|e|(e["operation"].as_str(),e["outcome"].as_str(),e["resolution"].as_str(),e["commit_attempted"].as_str())).collect();
    assert_eq!(boundaries,vec![("enroll","completed","unresolved","true"),("bind_rollback","completed","unresolved","true"),("rollback","completed","applied","true"),("bind_rollback","completed","applied","false"),("rollback","completed","applied","false")]);
    fixture::save("control-events-success.json",&values);
}
