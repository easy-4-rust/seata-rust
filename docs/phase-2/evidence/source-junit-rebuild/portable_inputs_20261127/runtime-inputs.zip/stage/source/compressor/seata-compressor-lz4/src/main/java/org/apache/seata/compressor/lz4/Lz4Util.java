/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.seata.compressor.lz4;

import net.jpountz.lz4.LZ4FrameInputStream;
import net.jpountz.lz4.LZ4FrameOutputStream;
import org.apache.seata.core.compressor.BoundedByteArrayOutputStream;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;

/**
 * the Lz4 Util
 *
 */
public class Lz4Util {
    private static final Logger LOGGER = LoggerFactory.getLogger(Lz4Util.class);
    private static final int ARRAY_SIZE = 1024;

    public static byte[] compress(byte[] bytes) {
        if (bytes == null) {
            throw new NullPointerException("bytes is null");
        }
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        try (LZ4FrameOutputStream lz4OutputStream = new LZ4FrameOutputStream(outputStream)) {
            lz4OutputStream.write(bytes);
        } catch (IOException e) {
            LOGGER.error("compress bytes error", e);
        }
        return outputStream.toByteArray();
    }

    public static byte[] decompress(byte[] bytes) {
        return decompress(bytes, Integer.MAX_VALUE);
    }

    public static byte[] decompress(byte[] bytes, int maxOutputSize) {
        if (bytes == null) {
            throw new NullPointerException("bytes is null");
        }

        ByteArrayOutputStream outputStream = new BoundedByteArrayOutputStream(maxOutputSize);
        ByteArrayInputStream inputStream = new ByteArrayInputStream(bytes);
        try (LZ4FrameInputStream decompressedInputStream = new LZ4FrameInputStream(inputStream)) {
            int count;
            byte[] buffer = new byte[ARRAY_SIZE];
            while ((count = decompressedInputStream.read(buffer)) != -1) {
                outputStream.write(buffer, 0, count);
            }
        } catch (IOException e) {
            LOGGER.error("decompress bytes error", e);
        }
        return outputStream.toByteArray();
    }
}
