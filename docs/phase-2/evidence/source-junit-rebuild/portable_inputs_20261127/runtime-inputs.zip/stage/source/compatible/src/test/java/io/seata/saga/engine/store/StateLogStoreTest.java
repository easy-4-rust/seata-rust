/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.seata.saga.engine.store;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Test cases for StateLogStore interface compatibility wrapper.
 */
public class StateLogStoreTest {

    @Test
    public void testDeprecatedAnnotation() {
        assertTrue(
                StateLogStore.class.isAnnotationPresent(Deprecated.class),
                "StateLogStore should be marked as @Deprecated");
    }

    @Test
    public void testIsInterface() {
        assertTrue(StateLogStore.class.isInterface(), "StateLogStore should be an interface");
    }

    @Test
    public void testHasSameMethodSignatures() {
        // Verify that the interface has the main methods of Apache StateLogStore
        assertTrue(StateLogStore.class.isInterface(), "StateLogStore should be an interface");
        try {
            StateLogStore.class.getMethod("getStateMachineInstance", String.class);
            StateLogStore.class.getMethod("getStateInstance", String.class, String.class);
        } catch (NoSuchMethodException e) {
            throw new AssertionError("StateLogStore should have same method signatures as Apache interface", e);
        }
    }
}
