/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.seata.saga.engine.expression;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Test cases for ExpressionFactory interface compatibility wrapper.
 */
public class ExpressionFactoryTest {

    @Test
    public void testDeprecatedAnnotation() {
        assertTrue(
                ExpressionFactory.class.isAnnotationPresent(Deprecated.class),
                "ExpressionFactory should be marked as @Deprecated");
    }

    @Test
    public void testIsInterface() {
        assertTrue(ExpressionFactory.class.isInterface(), "ExpressionFactory should be an interface");
    }

    @Test
    public void testExtendsApacheExpressionFactory() {
        assertTrue(
                org.apache.seata.saga.engine.expression.ExpressionFactory.class.isAssignableFrom(
                        ExpressionFactory.class),
                "ExpressionFactory should extend org.apache.seata.saga.engine.expression.ExpressionFactory");
    }
}
