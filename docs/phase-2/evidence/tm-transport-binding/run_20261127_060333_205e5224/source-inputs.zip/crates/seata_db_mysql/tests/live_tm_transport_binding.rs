//! 真实 TLS/MySQL 下，持久来源必须拒绝 TC 信任降级。
#![cfg(feature = "transport_tls")]
#![allow(clippy::unwrap_used)]
#[path = "support/owned_mysql.rs"]
mod owned_mysql;
#[path = "../../seata_transport/tests/support/tls_peer.rs"]
mod tls_peer;
#[path = "../../seata_transport/tests/support/session_peer.rs"]
#[allow(dead_code)]
mod peer;
use seata_db_mysql::{MySqlDataSource, MySqlLauncherStore};
use seata_protocol::{Message, GlobalStatus};
use seata_tm::{TransactionManager, TransactionConfig, TmError};
use seata_transport::RegistrationIdentity;
use sqlx::Executor;
use std::{sync::{Arc, atomic::{AtomicU64, Ordering}}, time::Duration};
use tokio::{io::{AsyncRead, AsyncReadExt, AsyncWrite}, net::TcpListener};

async fn optional_frame(stream: &mut (impl AsyncRead + Unpin)) -> Option<seata_protocol::protocol::RpcMessage> {
    let mut header=[0;16];
    match stream.read_exact(&mut header[..1]).await {
        Ok(_) => {},
        Err(error) if matches!(error.kind(),std::io::ErrorKind::UnexpectedEof|std::io::ErrorKind::ConnectionReset) => return None,
        Err(error) => panic!("fixture read failed: {error}"),
    }
    stream.read_exact(&mut header[1..]).await.unwrap();
    let size=u32::from_be_bytes(header[3..7].try_into().unwrap()) as usize;
    assert!((16..=65536).contains(&size));
    let mut bytes=header.to_vec();bytes.resize(size,0);stream.read_exact(&mut bytes[16..]).await.unwrap();
    Some(seata_protocol::v1::ProtocolDecoderV1::new(tls_peer::limits()).decode(&bytes).unwrap())
}

fn identity() -> RegistrationIdentity {
    RegistrationIdentity::new("1.1.0".into(),"tm-trust".into(),"tm-trust-group".into(),None).unwrap()
}

async fn serve(stream: &mut (impl AsyncRead + AsyncWrite + Unpin), queries: &AtomicU64) {
    while let Some(request)=optional_frame(stream).await {
        let body=match request.body.unwrap() {
            Message::RegisterTMRequest(_) => Message::RegisterTMResponse(seata_protocol::protocol::RegisterTMResponse { identified:true,wire_version:None }),
            Message::GlobalBeginRequest(_) => peer::begin_result("tc:launcher-trust"),
            Message::GlobalStatusRequest(_) => {
                queries.fetch_add(1,Ordering::SeqCst);
                Message::GlobalStatusResponse(seata_protocol::transaction::GlobalStatusResponse {
                    response:peer::success(),global_status:GlobalStatus::Committed,
                })
            },
            other => panic!("unexpected original frame: {other:?}"),
        };
        tls_peer::write(stream,peer::reply(request.id,body)).await;
    }
}

#[tokio::test]
#[ignore = "requires owned MySQL and native mTLS fixture"]
async fn persisted_tls_origin_rejects_plaintext_replacement_before_status_request() {
    let mut admin=owned_mysql::admin().await;
    admin.execute("DROP TABLE IF EXISTS seata_rs_tm_launcher_v1").await.unwrap();
    for migration in [include_str!("../migrations/008_seata_rs_tm_launcher_v1.sql"),
        include_str!("../migrations/009_seata_rs_tm_launcher_owner_instance.sql"),
        include_str!("../migrations/010_seata_rs_tm_launcher_stop_scope.sql"),
        include_str!("../migrations/014_seata_rs_tm_transport_binding.sql")] {
        sqlx::raw_sql(migration).execute(&mut admin).await.unwrap();
    }
    let source=MySqlDataSource::connect(owned_mysql::options(None)).await.unwrap();
    let store=MySqlLauncherStore::new(source.clone());
    let pki=tls_peer::Pki::new();let security=pki.client("seata.example.test");let acceptor=pki.acceptor();
    let listener=TcpListener::bind("127.0.0.1:0").await.unwrap();let address=listener.local_addr().unwrap();
    let queries=Arc::new(AtomicU64::new(0));let observed=queries.clone();
    let server=tokio::spawn(async move {
        let (socket,_)=listener.accept().await.unwrap();let mut tls=acceptor.accept(socket).await.unwrap();
        serve(&mut tls,&observed).await;drop(tls);
        // 同一个受控端点随后提供明文对端，模拟端口复用后的降级。
        let (mut socket,_)=listener.accept().await.unwrap();serve(&mut socket,&observed).await;
    });
    let original=TransactionManager::builder(tls_peer::pool(address),identity()).transport_tls(security).build().unwrap();
    let config=TransactionConfig::builder("trust-source".into()).transaction_timeout(Duration::from_secs(60)).build().unwrap();
    let durable=original.begin_durable(&config,"trust-business",&store).await.unwrap();
    let xid=durable.xid().clone();drop(durable);original.shutdown().await.unwrap();
    let snapshot=store.load_snapshot(&xid).await.unwrap().unwrap();
    let replacement=TransactionManager::builder(tls_peer::pool(address),identity()).request_timeout(Duration::from_secs(2)).build().unwrap();
    tokio::time::timeout(Duration::from_secs(2),async {
        while replacement.connection_snapshot().ready()==0 {tokio::task::yield_now().await;}
    }).await.unwrap();
    let result=snapshot.query_original_tc(&replacement,"trust-business").await;
    assert!(matches!(result,Err(TmError::IllegalState{..})),"TLS source cannot trust a plaintext replacement: {result:?}");
    assert_eq!(queries.load(Ordering::SeqCst),0);
    replacement.shutdown().await.unwrap();server.await.unwrap();source.close().await.unwrap();
}
