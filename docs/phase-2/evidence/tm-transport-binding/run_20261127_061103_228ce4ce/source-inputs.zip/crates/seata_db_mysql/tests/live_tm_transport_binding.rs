//! 真实 TLS/MySQL 下，持久来源必须拒绝 TC 信任降级。
#![cfg(feature = "transport_tls")]
#![allow(clippy::unwrap_used)]
#[path = "support/owned_mysql.rs"]
mod owned_mysql;
#[path = "../../seata_transport/tests/support/tls_peer.rs"]
mod tls_peer;
#[path = "../../seata_transport/tests/support/session_peer.rs"]
#[allow(dead_code)]
mod peer;
use seata_db_mysql::{MySqlDataSource, MySqlLauncherStore};
use seata_protocol::{Message, GlobalStatus};
use seata_tm::{TransactionManager, TransactionConfig, TmError};
use seata_transport::RegistrationIdentity;
use sqlx::Executor;
use std::{sync::{Arc, atomic::{AtomicU64, Ordering}}, time::Duration};
use tokio::{io::{AsyncRead, AsyncReadExt, AsyncWrite}, net::TcpListener};
#[path = "../../seata_tm/tests/support/tm_peer.rs"]
mod tm_fixture;
use seata_tm::{LauncherOrigin, LauncherStore, LauncherProcessMonitor, TmOperation};

async fn optional_frame(stream: &mut (impl AsyncRead + Unpin)) -> Option<seata_protocol::protocol::RpcMessage> {
    let mut header=[0;16];
    match stream.read_exact(&mut header[..1]).await {
        Ok(_) => {},
        Err(error) if matches!(error.kind(),std::io::ErrorKind::UnexpectedEof|std::io::ErrorKind::ConnectionReset) => return None,
        Err(error) => panic!("fixture read failed: {error}"),
    }
    stream.read_exact(&mut header[1..]).await.unwrap();
    let size=u32::from_be_bytes(header[3..7].try_into().unwrap()) as usize;
    assert!((16..=65536).contains(&size));
    let mut bytes=header.to_vec();bytes.resize(size,0);stream.read_exact(&mut bytes[16..]).await.unwrap();
    Some(seata_protocol::v1::ProtocolDecoderV1::new(tls_peer::limits()).decode(&bytes).unwrap())
}

fn identity() -> RegistrationIdentity {
    RegistrationIdentity::new("1.1.0".into(),"tm-trust".into(),"tm-trust-group".into(),None).unwrap()
}

async fn serve(stream: &mut (impl AsyncRead + AsyncWrite + Unpin), queries: &AtomicU64) {
    while let Some(request)=optional_frame(stream).await {
        let body=match request.body.unwrap() {
            Message::RegisterTMRequest(_) => Message::RegisterTMResponse(seata_protocol::protocol::RegisterTMResponse { identified:true,wire_version:None }),
            Message::GlobalBeginRequest(_) => peer::begin_result("tc:launcher-trust"),
            Message::GlobalStatusRequest(_) => {
                queries.fetch_add(1,Ordering::SeqCst);
                Message::GlobalStatusResponse(seata_protocol::transaction::GlobalStatusResponse {
                    response:peer::success(),global_status:GlobalStatus::Committed,
                })
            },
            other => panic!("unexpected original frame: {other:?}"),
        };
        tls_peer::write(stream,peer::reply(request.id,body)).await;
    }
}

#[tokio::test]
#[ignore = "requires owned MySQL and native mTLS fixture"]
async fn persisted_tls_origin_rejects_plaintext_replacement_before_status_request() {
    let mut admin=owned_mysql::admin().await;
    admin.execute("DROP TABLE IF EXISTS seata_rs_tm_launcher_v1").await.unwrap();
    for migration in [include_str!("../migrations/008_seata_rs_tm_launcher_v1.sql"),
        include_str!("../migrations/009_seata_rs_tm_launcher_owner_instance.sql"),
        include_str!("../migrations/010_seata_rs_tm_launcher_stop_scope.sql"),
        include_str!("../migrations/014_seata_rs_tm_transport_binding.sql")] {
        sqlx::raw_sql(migration).execute(&mut admin).await.unwrap();
    }
    let source=MySqlDataSource::connect(owned_mysql::options(None)).await.unwrap();
    let store=MySqlLauncherStore::new(source.clone());
    let pki=tls_peer::Pki::new();let security=pki.client("seata.example.test");let acceptor=pki.acceptor();
    let listener=TcpListener::bind("127.0.0.1:0").await.unwrap();let address=listener.local_addr().unwrap();
    let queries=Arc::new(AtomicU64::new(0));let observed=queries.clone();
    let server=tokio::spawn(async move {
        let (socket,_)=listener.accept().await.unwrap();let mut tls=acceptor.accept(socket).await.unwrap();
        serve(&mut tls,&observed).await;drop(tls);
        // 同一个受控端点随后提供明文对端，模拟端口复用后的降级。
        let (mut socket,_)=listener.accept().await.unwrap();serve(&mut socket,&observed).await;
    });
    let original=TransactionManager::builder(tls_peer::pool(address),identity()).transport_tls(security).build().unwrap();
    let config=TransactionConfig::builder("trust-source".into()).transaction_timeout(Duration::from_secs(60)).build().unwrap();
    let durable=original.begin_durable(&config,"trust-business",&store).await.unwrap();
    let xid=durable.xid().clone();drop(durable);original.shutdown().await.unwrap();
    let snapshot=store.load_snapshot(&xid).await.unwrap().unwrap();
    let replacement=TransactionManager::builder(tls_peer::pool(address),identity()).request_timeout(Duration::from_secs(2)).build().unwrap();
    tokio::time::timeout(Duration::from_secs(2),async {
        while replacement.connection_snapshot().ready()==0 {tokio::task::yield_now().await;}
    }).await.unwrap();
    let result=snapshot.query_original_tc(&replacement,"trust-business").await;
    assert!(matches!(result,Err(TmError::IllegalState{..})),"TLS source cannot trust a plaintext replacement: {result:?}");
    assert_eq!(queries.load(Ordering::SeqCst),0);
    replacement.shutdown().await.unwrap();server.await.unwrap();source.close().await.unwrap();
}

async fn schema(admin: &mut sqlx::MySqlConnection, upgraded: bool) {
    admin.execute("DROP TABLE IF EXISTS seata_rs_tm_launcher_v1").await.unwrap();
    for sql in [include_str!("../migrations/008_seata_rs_tm_launcher_v1.sql"),
        include_str!("../migrations/009_seata_rs_tm_launcher_owner_instance.sql"),
        include_str!("../migrations/010_seata_rs_tm_launcher_stop_scope.sql")] {
        sqlx::raw_sql(sql).execute(&mut *admin).await.unwrap();
    }
    if upgraded {sqlx::raw_sql(include_str!("../migrations/014_seata_rs_tm_transport_binding.sql")).execute(&mut *admin).await.unwrap();}
}

struct ExitAfterIntent(MySqlLauncherStore);
impl LauncherStore for ExitAfterIntent {
    async fn record_begin(&self,origin:&LauncherOrigin)->Result<(),Box<dyn std::error::Error+Send+Sync>> {
        self.0.record_begin(origin).await
    }
    async fn record_end_intent(&self,origin:&LauncherOrigin,operation:TmOperation)->Result<(),Box<dyn std::error::Error+Send+Sync>> {
        self.0.record_end_intent(origin,operation).await?;
        std::process::exit(0);
    }
    async fn mark_send_started(&self,origin:&LauncherOrigin,operation:TmOperation)->Result<(),Box<dyn std::error::Error+Send+Sync>> {
        self.0.mark_send_started(origin,operation).await
    }
}

#[tokio::test]
#[ignore = "owned child entry; parent validates actual process stop proof"]
async fn binding_owner_child() {
    let folder=std::path::PathBuf::from(std::env::var("SEATA_TM_TRUST_MATERIAL").unwrap());
    let read=|name|std::fs::read(folder.join(name)).unwrap();
    let security=seata_transport::TlsClientConfig::new("seata.example.test".into(),vec![read("root.der")],vec![read("client.der")],read("client.key.der")).unwrap();
    let address=std::env::var("SEATA_TM_TRUST_ENDPOINT").unwrap().parse().unwrap();
    let manager=TransactionManager::builder(tls_peer::pool(address),identity()).transport_tls(security).build().unwrap();
    use std::io::Write;
    std::io::stdout().lock().write_all(b"\n").unwrap();
    manager.announce_supervised_instance(std::io::stdout().lock()).unwrap();
    let source=MySqlDataSource::connect(owned_mysql::options(None)).await.unwrap();
    let store=ExitAfterIntent(MySqlLauncherStore::new(source));
    let config=TransactionConfig::builder("bound-child".into()).transaction_timeout(Duration::from_secs(60)).build().unwrap();
    manager.begin_durable(&config,"trust-business",&store).await.unwrap().commit().await.unwrap();
    panic!("owner must stop after durable intent and before send marker");
}

async fn serve_pending(stream: &mut (impl AsyncRead+AsyncWrite+Unpin),queries:&AtomicU64,ends:&AtomicU64) {
    while let Some(request)=optional_frame(stream).await {
        let body=match request.body.unwrap() {
            Message::RegisterTMRequest(_) => Message::RegisterTMResponse(seata_protocol::protocol::RegisterTMResponse{identified:true,wire_version:None}),
            Message::GlobalBeginRequest(_) => peer::begin_result("tc:launcher-trust"),
            Message::GlobalStatusRequest(_) => {
                queries.fetch_add(1,Ordering::SeqCst);
                Message::GlobalStatusResponse(seata_protocol::transaction::GlobalStatusResponse{response:peer::success(),global_status:if ends.load(Ordering::SeqCst)==0 {GlobalStatus::Begin}else{GlobalStatus::Committed}})
            },
            Message::GlobalCommitRequest(_) => {ends.fetch_add(1,Ordering::SeqCst);tm_fixture::end_response(true,GlobalStatus::Committed,peer::success())},
            other=>panic!("unexpected recovery frame: {other:?}"),
        };
        tls_peer::write(stream,peer::reply(request.id,body)).await;
    }
}

#[tokio::test]
#[ignore = "requires owned MySQL and actual monitored mTLS owner process"]
async fn same_trust_stopped_owner_transfers_after_binding_race_is_rejected() {
    let mut admin=owned_mysql::admin().await;schema(&mut admin,true).await;
    let source=MySqlDataSource::connect(owned_mysql::options(None)).await.unwrap();let store=MySqlLauncherStore::new(source.clone());
    let pki=tls_peer::Pki::new();let security=pki.client("seata.example.test");let binding=*security.peer_trust_binding();let acceptor=pki.acceptor();
    let folder=std::path::PathBuf::from(format!("D:/codex-builds/tm-trust-owner-{}-{}",std::process::id(),std::time::SystemTime::now().duration_since(std::time::UNIX_EPOCH).unwrap().as_nanos()));
    std::fs::create_dir_all(&folder).unwrap();
    for (name,bytes) in [("root.der",pki.root),("client.der",pki.client_certificate),("client.key.der",pki.client_key)] {std::fs::write(folder.join(name),bytes).unwrap();}
    let listener=TcpListener::bind("127.0.0.1:0").await.unwrap();let address=listener.local_addr().unwrap();
    let queries=Arc::new(AtomicU64::new(0));let ends=Arc::new(AtomicU64::new(0));let observed=queries.clone();let completed=ends.clone();
    let (stop,mut stopping)=tokio::sync::watch::channel(false);
    let server=tokio::spawn(async move {
        let mut workers=tokio::task::JoinSet::new();
        loop {tokio::select! {
            _=stopping.changed()=>break,
            accepted=listener.accept()=>{
                let (socket,_)=accepted.unwrap();let acceptor=acceptor.clone();let observed=observed.clone();let completed=completed.clone();
                workers.spawn(async move {if let Ok(mut stream)=acceptor.accept(socket).await {serve_pending(&mut stream,&observed,&completed).await;}});
            }
        }}
        while let Some(result)=workers.join_next().await {result.unwrap();}
    });
    let mut command=std::process::Command::new(std::env::current_exe().unwrap());
    command.args(["--ignored","--exact","binding_owner_child","--nocapture"])
        .env("SEATA_TM_TRUST_ENDPOINT",address.to_string()).env("SEATA_TM_TRUST_MATERIAL",&folder);
    let mut monitor=LauncherProcessMonitor::spawn(&mut command).unwrap();
    let stopped=tokio::time::timeout(Duration::from_secs(10),async {
        loop {if let Some(proof)=monitor.try_confirm_exit().unwrap() {break proof;}tokio::time::sleep(Duration::from_millis(10)).await;}
    }).await.unwrap();
    let xid=seata_tm::Xid::parse("tc:launcher-trust".into()).unwrap();
    let snapshot=store.load_snapshot(&xid).await.unwrap().unwrap();
    assert_eq!(snapshot.peer_trust_binding(),Some(&binding));assert!(monitor.verifies(&stopped,snapshot.owner_instance_id()));
    assert_eq!(snapshot.end_operation(),Some(TmOperation::Commit));assert!(!snapshot.send_started());
    let (manager,authority)=TransactionManager::builder(tls_peer::pool(address),identity()).transport_tls(security).build_with_recovered_end_authority().unwrap();
    assert_eq!(manager.peer_trust_binding(),Some(&binding));
    // 真正取得源行锁，在接管者已进入 MySQL 锁等待后替换绑定，不能只依赖旧快照。
    use sqlx::Connection;
    {
    let mut blocker=admin.begin().await.unwrap();
    sqlx::query("SELECT xid_digest FROM seata_rs_tm_launcher_v1 FOR UPDATE").fetch_one(&mut *blocker).await.unwrap();
    let mut observer=owned_mysql::admin().await;
    let claim=store.transfer_stopped_owner(&snapshot,&monitor,&stopped,&manager,"trust-business");tokio::pin!(claim);
    tokio::select! {
        result=&mut claim=>match result {Ok(_)=>panic!("claim succeeded before lock release"),Err(error)=>panic!("claim must wait for the source lock: {error:?}")},
        waited=tokio::time::timeout(Duration::from_secs(3),async {
            loop {
                let waits:i64=sqlx::query_scalar("SELECT COUNT(*) FROM information_schema.innodb_trx WHERE trx_state='LOCK WAIT' AND trx_query LIKE '%seata_rs_tm_launcher_v1%'").fetch_one(&mut observer).await.unwrap();
                if waits>0 {break;}tokio::time::sleep(Duration::from_millis(10)).await;
            }
        })=>{waited.unwrap();}
    }
    let wrong=[0x72u8;32];
    sqlx::query("UPDATE seata_rs_tm_launcher_v1 SET transport_binding=?").bind(wrong.as_slice()).execute(&mut *blocker).await.unwrap();blocker.commit().await.unwrap();
    assert!(claim.await.is_err(),"locked claim must compare persisted transport binding");
    }
    let epoch:u64=sqlx::query_scalar("SELECT owner_epoch FROM seata_rs_tm_launcher_v1").fetch_one(&mut admin).await.unwrap();assert_eq!(epoch,1);assert_eq!(ends.load(Ordering::SeqCst),0);
    sqlx::query("UPDATE seata_rs_tm_launcher_v1 SET transport_binding=?").bind(binding.as_slice()).execute(&mut admin).await.unwrap();
    let transferred=store.transfer_stopped_owner(&snapshot,&monitor,&stopped,&manager,"trust-business").await.unwrap();assert_eq!(transferred.epoch(),2);
    assert_eq!(transferred.finish(&authority,&store).await.unwrap().status(),GlobalStatus::Committed);
    let final_snapshot=store.load_snapshot(&xid).await.unwrap().unwrap();assert_eq!(final_snapshot.owner_epoch(),2);assert!(final_snapshot.send_started());assert_eq!(final_snapshot.peer_trust_binding(),Some(&binding));
    assert_eq!(ends.load(Ordering::SeqCst),1);assert!(queries.load(Ordering::SeqCst)>=3);
    manager.shutdown().await.unwrap();stop.send(true).unwrap();server.await.unwrap();source.close().await.unwrap();
}
