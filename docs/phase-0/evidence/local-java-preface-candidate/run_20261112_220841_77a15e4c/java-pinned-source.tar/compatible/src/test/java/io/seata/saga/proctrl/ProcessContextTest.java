/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.seata.saga.proctrl;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Test cases for ProcessContext interface compatibility wrapper.
 */
public class ProcessContextTest {

    @Test
    public void testDeprecatedAnnotation() {
        assertTrue(
                ProcessContext.class.isAnnotationPresent(Deprecated.class),
                "ProcessContext should be marked as @Deprecated");
    }

    @Test
    public void testIsInterface() {
        assertTrue(ProcessContext.class.isInterface(), "ProcessContext should be an interface");
    }

    @Test
    public void testExtendsApacheProcessContext() {
        assertTrue(
                org.apache.seata.saga.proctrl.ProcessContext.class.isAssignableFrom(ProcessContext.class),
                "ProcessContext should extend org.apache.seata.saga.proctrl.ProcessContext");
    }
}
